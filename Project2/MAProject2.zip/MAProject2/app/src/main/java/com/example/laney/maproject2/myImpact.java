package com.example.laney.maproject2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class myImpact extends Activity {

    //The following are private variables because I was trying to check when the user left an input blank, I just couldn't
    private EditText Ecigarette;
    private EditText EbottleNum;
    private EditText EbagNum;
    private EditText EwrappersNum;
    private EditText EstrawsNum;
    private EditText EbottleCapNum;
    private Button buttonConfirm;


    private TextView showCalc;
    private TextView setSad;
    private String showCalcMessage;
    private String setSadMessage;

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("msg",showCalcMessage);
        outState.putString("msgtwo",setSadMessage);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_impact);

        showCalc = findViewById(R.id.textView17);
        setSad = findViewById(R.id.textView18);

        if(savedInstanceState != null){
            showCalcMessage =savedInstanceState.getString("msg");
            setSadMessage = savedInstanceState.getString("msgtwo");
            showCalc.setText(showCalcMessage);
            setSad.setText(setSadMessage);
        }
    }
//fix if number is not entered case
    public void calculateImpact(View view){
         Ecigarette = findViewById(R.id.editText);//user input for number of cigarettes
         EbottleNum = findViewById(R.id.editText2);//user input for number of bottles
         EbagNum = findViewById(R.id.editText3); //user input for number of bags
         EwrappersNum = findViewById(R.id.editText4); //user input for number of wrappers
         EstrawsNum = findViewById(R.id.editText5); //user input for number of straws
         EbottleCapNum = findViewById(R.id.editText6);//user input for number of bottle caps
        buttonConfirm =  findViewById(R.id.button2);

        Spinner timeline = findViewById(R.id.spinner);
        String timelineRange = String.valueOf(timeline.getSelectedItem());
        //converting edit text to integers
        String ci = Ecigarette.getText().toString();
        int cigaretteNum = Integer.parseInt(ci);

        String bo = EbottleNum.getText().toString();
        int bottleNum=Integer.parseInt(bo);

        String ba = EbagNum.getText().toString();
        int bagNum=Integer.parseInt(ba);

        String wr = Ecigarette.getText().toString();
        int wrapperNum=Integer.parseInt(wr);

        String st = Ecigarette.getText().toString();
        int strawsNum=Integer.parseInt(st);

        String bc = Ecigarette.getText().toString();
        int bottleCapNum=Integer.parseInt(bc);

        int numYears;

        //The following are averages of the weights of the objects
        int cigaretteWeight = 1; //grams
        int bottleWeight = 12; //grams
        int bagWeight = 6; //grams
        int wrapperWeight = 2; //grams
        int strawsWeight = 1; //grams
        int capWeight = 4; //grams

        switch (timelineRange){
            case "In 20 years":
                numYears = 20;
                break;
            case "In 50 years":
                numYears = 50;
                break;
            case "In 75 years":
                numYears = 75;
                break;
            default:
                numYears = 20;
        }
        //math calculations

        int Tci = ((cigaretteNum*cigaretteWeight)*52*numYears);
        int Tbo = ((bottleNum*bottleWeight)*52*numYears);
        int Tba = ((bagNum*bagWeight)*52*numYears);
        int Twr = ((wrapperNum*wrapperWeight)*52*numYears);
        int Tst = ((strawsNum*strawsWeight)*52*numYears);
        int Tbc = ((bottleCapNum*capWeight)*52*numYears);

        int TW = (Tci+Tbo+Tba+Twr+Tst+Tbc);
//        double TWd = (double) TW;
        double TWlbs =Math.floor(TW*0.002204);

        //int TotalWeight = Math.floor(TWlbs);

        showCalc = findViewById(R.id.textView17);
        showCalcMessage = ("In " +numYears+ " you would make "+TWlbs +"lbs of trash");
        showCalc.setText(showCalcMessage);
        showCalc.setVisibility(View.VISIBLE);

        String sadStatment = "That is too much waste.";
        if(TWlbs<200){
            sadStatment = "That is ≈ the size of a dog.";
        }
        if((TWlbs>=200)&&(TWlbs<300)){
            sadStatment = "That is ≈ the size of a baby elephant.";
        }
        if((TWlbs>=300)&&(TWlbs<700)){
            sadStatment = "That is ≈ a cubic meter of snow.";
        }
        if((TWlbs>=700)&&(TWlbs<2000)){
            sadStatment = "That is ≈ 2 grand pianos.";
        }
        if((TWlbs>=2000)&&(TWlbs<2500)){
            sadStatment = "That is ≈ 2 grizzly bears.";
        }
        if ((TWlbs>=2500)&&(TWlbs<3000)){
            sadStatment = "That is ≈ 6 cubic meters of snow.";
        }
        if ((TWlbs>=3000)&&(TWlbs<3500)){
            sadStatment = "That is ≈ the size of a car.";
        }
        if((TWlbs>=3500)&& (TWlbs<4000)){
            sadStatment = "That is ≈ the size of the tounge of a blue whale.";
        }
        if(TWlbs>4000){
            sadStatment = "That is ≈ enough to make every sea creature cry.";
        }

        setSad = findViewById(R.id.textView18);
        setSadMessage = (sadStatment);
        setSad.setText(setSadMessage);
        setSad.setVisibility(View.VISIBLE);
    }
}

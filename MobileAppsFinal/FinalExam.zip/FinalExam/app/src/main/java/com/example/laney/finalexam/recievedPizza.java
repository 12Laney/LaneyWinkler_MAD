package com.example.laney.finalexam;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class recievedPizza extends Activity {
 private String pizzaPlace;
 private String pizzaPlaceURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recieved_pizza);

        Intent intent = getIntent();
        pizzaPlace = intent.getStringExtra("pizzaShopName");
        //add url
        TextView messageView = findViewById(R.id.textView3);
        messageView.setText("You should check out " + pizzaPlace);
    }
}

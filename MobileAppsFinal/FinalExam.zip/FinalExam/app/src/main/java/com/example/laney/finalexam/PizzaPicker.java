package com.example.laney.finalexam;

public class PizzaPicker {
    private String pizzaShop;
    private String pizzaShopURL;

    private void setPizzaInfo(Integer pizzaSize){
        switch (pizzaSize){
            case 0: //Small pizza
                pizzaShop="Pizzeria Locale";
                pizzaShopURL="https://localeboulder.com/";
                break;
            case 1: //medieum pizza
                pizzaShop = "Old Chicago";
                pizzaShopURL = "https://backcountrypizzaandtaphouse.info/";
                break;
            case 2: //large Pizza
                pizzaShop = "Boss Lady";
                pizzaShopURL = "http://bossladypizza.com/";
                break;
             default:
                 pizzaShop = "Boss Lady";
                 pizzaShopURL = "http://bossladypizza.com/";
        }
    }

    public void setPizzaShop(Integer pizzaSize){
        setPizzaInfo(pizzaSize);
    }
    public void setPizzaShopURL(Integer pizzaSize){
        setPizzaInfo(pizzaSize);
    }
    public String getPizzaShop(){
        return pizzaShop;
    }
    public String getPizzaShopURL(){
        return pizzaShopURL;
    }
}

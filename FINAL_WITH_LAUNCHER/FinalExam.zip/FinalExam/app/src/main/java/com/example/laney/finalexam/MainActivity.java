package com.example.laney.finalexam;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {

    private PizzaPicker mypizzashop = new PizzaPicker();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button2);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findpizza(view);
            }
        };
        button.setOnClickListener(onclick);

    }

    //Info for the second screen (pizza size determines type of pizza)
    public void findpizza(View view){
        Spinner pizzaSizeSpinner = findViewById(R.id.spinner);
        Integer pizzaSize = pizzaSizeSpinner.getSelectedItemPosition();
        mypizzashop.setPizzaShop(pizzaSize);
        String suggestedPizzaPlace = mypizzashop.getPizzaShop();
        String suggestedPizzaURL = mypizzashop.getPizzaShopURL();
        Intent intent = new Intent(this, recievedPizza.class);
        intent.putExtra("pizzaShopName", suggestedPizzaPlace);

        startActivity(intent);
    }

    public void MakePizza(View view) {
        //Toggle for red or white sauce

        ToggleButton toggle = findViewById(R.id.toggleButton);
        boolean SauceType = toggle.isChecked();

        ToggleButton toggle2 = findViewById(R.id.toggleButton2);
        boolean ToppingType = toggle2.isChecked();

        //Spinner for pizza size

        Spinner PizzaSize = findViewById(R.id.spinner);
        String pizzaSizeWords = String.valueOf(PizzaSize.getSelectedItem());

        //Radio Button for crust

        RadioGroup crustType = findViewById(R.id.radioGroup);
        int crustTypeId = crustType.getCheckedRadioButtonId();

        //Image View
        ImageView image = (ImageView) findViewById(R.id.imageView);
        //Default settings to troubleshoot
        String myPizzaSize = "small";
        String myPizzaSauce = "red";
        String pizzaCrustType = "thin";
        String Toppings = "with no toppings";

        if (crustTypeId == -1) {//if no crust selected
            //For my toast
            Context context = getApplicationContext();
            CharSequence text = "Please select a type of crust";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        } else {
            if (SauceType) {//if white sauce
                myPizzaSauce = "white";
                switch (pizzaSizeWords) {
                    case "Small":
                        myPizzaSize = "small";
                        break;
                    case "Medium":
                        myPizzaSize = "medium";
                        break;
                    case "Large":
                        myPizzaSize = "large";
                        break;
                    default:
                        myPizzaSize = "no chosen size";

                }

            } else {//if red sauce
                myPizzaSauce = "red";
                switch (pizzaSizeWords) {
                    case "Small":
                        myPizzaSize = "small";
                        break;
                    case "Medium":
                        myPizzaSize = "medium";
                        break;
                    case "Large":
                        myPizzaSize = "large";
                        break;
                    default:
                        myPizzaSize = "no chosen size";

                }

            }
        }
        if (crustTypeId == R.id.radioButton) {
            pizzaCrustType = "thin";
        }
        if (crustTypeId == R.id.radioButton2) {
            pizzaCrustType = "thick";
        }
        if (ToppingType) {
            Toppings = "with no toppings";
            image.setImageResource(R.drawable.pizza_cheese);
        } else {
            Toppings = "with toppings";
            image.setImageResource(R.drawable.pizza_veggie);
        }

            EditText getPizzaName = findViewById(R.id.editText);
            String PizzaName = getPizzaName.getText().toString();
            TextView pizzaReviewed = findViewById(R.id.textView2);

            pizzaReviewed.setText(PizzaName + " is a " + myPizzaSize + " pizza with "+ myPizzaSauce + " sauce, " + Toppings +", and a " + pizzaCrustType + " crust");


    }
}
